import json
import uuid
import boto3

def lambda_handler(event, context):
    db_client = boto3.client('dynamodb')
    
    row_key = uuid.uuid4().hex
    
    telemetry_entity = {
        'SpeedDesired': {'N': str(event['speed_desired'])},
        'AmbientTemperature': {'N': str(event['ambient_temperature'])},
        'AmbientPressure': {'N': str(event['ambient_pressure'])},
        'Speed': {'N': str(event['speed'])},
        'Temperature': {'N': str(event['temperature'])},
        'Pressure': {'N': str(event['pressure'])},
        'Vibration': {'S': str(event['vibration'])},
        'Timestamp': {'S': str(event['timestamp'])},
        'MachineID': {'S': str(event['machineID'])},
        'RowKey': {'S': row_key},
    }
        
    db_client.put_item(TableName='telemetry_db', Item=telemetry_entity)
    
    k_client = boto3.client('kinesis')
    telemetry_entity_stream = {
        'SpeedDesired': event['speed_desired'],
        'AmbientTemperature': event['ambient_temperature'],
        'AmbientPressure': event['ambient_pressure'],
        'Speed': event['speed'],
        'Temperature': event['temperature'],
        'Pressure': event['pressure'],
        'Vibration': event['vibration'],
        'Timestamp': event['timestamp'],
        'MachineID': event['machineID'],
        'RowKey': row_key
    }

    put_response = k_client.put_record(
                    StreamName='telemetry_stream',
                    Data=json.dumps(telemetry_entity_stream),
                    PartitionKey=event['machineID'])
    
    return {
        'statusCode': 200,
        'body': json.dumps(telemetry_entity_stream)
    }
    
