import json
import uuid
import boto3

def lambda_handler(event, context):
    db_client = boto3.client('dynamodb')
    row_key = uuid.uuid4().hex
    
    log_entity = {
            'PartitionKey': {'S': event['machineID'] },
            'RowKey': {'S': row_key },
            'Level': {'S': event['level'] },
            'Code': {'S': event['code'] },
            'Message': {'S': event['message'] },
            '_Driver': {'S': event['_driver'] },
            'Timestamp': {'N': event['timestamp'] }
        }
        
    db_client.put_item(TableName='logs_db', Item=log_entity)
    
    k_client = boto3.client('kinesis')
    log_entity_stream = {
            'PartitionKey': event['machineID'],
            'RowKey': row_key,
            'Level': event['level'],
            'Code': event['code'],
            'Message': event['message'],
            '_Driver': event['_driver'],
            'Timestamp': event['timestamp']
        }
        
    put_response = k_client.put_record(
                    StreamName='logs_stream',
                    Data=json.dumps(log_entity_stream),
                    PartitionKey=event['machineID'])
    
    return {
        'statusCode': 200,
        'body': json.dumps(log_entity_stream)
    }